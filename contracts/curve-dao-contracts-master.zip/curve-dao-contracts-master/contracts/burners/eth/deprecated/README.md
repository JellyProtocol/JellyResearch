# curve-dao-contracts/contracts/burners/deprecated

Fee burner contracts which are no longer in use.
