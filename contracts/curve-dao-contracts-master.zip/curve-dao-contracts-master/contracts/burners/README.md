# curve-dao-contracts/contracts/burners/deprecated

Contracts used to convert admin fees into 3CRV prior to distribution to the DAO.

View the [documentation](https://curve.readthedocs.io/dao-fees.html#the-burn-process) to learn more about the fee burning process and how to interact with these contracts.
